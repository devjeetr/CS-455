mcs *.cs
mono Handler.exe
